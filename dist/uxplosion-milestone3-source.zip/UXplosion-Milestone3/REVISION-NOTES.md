# LearningLab source package — revised 10 November 2026

This is a revised copy of the **uploaded older ZIP**, not an edit to the live ChatGPT-hosted website. To update the live website, replace/redeploy its source separately.

## Corrections

1. English and German sample exam questions, answers, and model answers now match the selected exam language.
2. In the simulated OCR example, Question 2 intentionally starts as `3 × 4 = 17` while the original says `3 × 4 = 12`. The teacher must correct it. The grading suggestion now follows the verified answer: 5/5 for 12 and 0/5 for 17, with teacher override retained.
3. Learning-gap confirmation requires the teacher to review the current answer and explicitly acknowledge checking it against earlier evidence. This does not claim an AI semantic validator.
4. The support plan includes a separately selectable, measurable target of 3, 4 or 5 correct comparisons out of five.
5. Navigation labels and all six editable HTDs updated to use Support plans, Students, Help & support, and Confirm answers & continue.
6. Download source package button is backed by a ZIP included inside `dist`.
7. Only Mathematics is selectable in this packaged demonstration. The language choice is English or German. Other subjects are outside the scope of the included sample.

## Validation

- `node --check dist/app.js` passes.
- Automated Chromium interaction test passed: German sample upload, simulated OCR correction, correct grading suggestion, mandatory evidence acknowledgement, separate support-flag decision, result release, student results, support-plan target save, and incorrect OCR grading branch.
- The browser test ran using inlined HTML/CSS/JS because direct localhost and file navigation were blocked in the testing environment.
- The public hosted website has not been redeployed or independently tested.

## Final website fixes (10 November 2026)

- Students can submit a second exam after the teacher releases the first. Previously released assessments remain available in the assessment history, with their own grades and teacher feedback.
- Student results explicitly show the teacher-confirmed learning focus and extra-support recommendation in child-friendly language.
- A new exam has an editable assessment title; the sample exam supports English or German.
- The teacher chooses and confirms the simulated follow-up evidence scenario. A successful outcome is blocked when the score is below the chosen measurable target. Updating the target reopens an inconsistent previous success outcome.
- Resetting the file chooser now clears stale file metadata.
- Desktop and 390px mobile layouts tested; no horizontal document overflow in the mobile dashboard.
- Original hosted ChatGPT site has NOT been modified; redeploy the `dist/` folder to publish these fixes.


## Student dashboard and localization improvements
- Score chart now uses the same released assessment records as My exams, including archived submissions and labelled sample follow-ups; displays the latest eight records.
- Completed assessment count, latest score, and unread update count are derived from the same data, rather than hard-coded values.
- Teacher release creates a persistent notification linked to its assessment. Earlier messages remain accessible after a new upload, and reading one marks only that message read.
- German sample submissions get German default teacher feedback and practice suggestions; teachers can edit both before release.
- Narrow-screen styles stack OCR comparison and grading panels, allow horizontal scrolling for wide tables, and improve chart labels.

## November 10, 2026 — Targeted three-issue reliability update

- All three fictional OCR answers now produce question-specific *suggested* marks when the teacher confirms the extracted text; final marks remain teacher-editable. These narrow demonstration rules are not a general OCR or AI-grading system.
- Editing the saved written intervention goal invalidates an earlier "Successful" outcome so the teacher can reassess it. Existing target and completion checks are preserved.
- The progress history orders sample follow-up evidence and newly released exams by their recorded review/release times, so an older follow-up does not incorrectly become the latest result. Older saved demo records without timestamps use dated fallback ordering.
- No changes to HTML, CSS, sidebar, Help & support, HTDs, or other screens.
