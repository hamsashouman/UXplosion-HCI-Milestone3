# UXplosion walkthrough — target 3 minutes 45 seconds

0:00–0:30 — “Learning Lab supports Grades 1–5 students and teachers. Our unique feature tracks recurring misconceptions across exams, with evidence confirmed by a teacher.” Show the student dashboard.

0:30–1:00 — Open Upload an exam. Choose Mathematics and English or German, then Use a sample exam. Preview the paper and submit. “Students cannot see an unapproved AI grade.”

1:00–1:45 — Switch to Teacher view, open Assessment review, and continue. Correct question 2 from 17 to 12. Confirm answers. Change marks to 1, 5, 5; confirm grades. “Teachers can correct OCR and override AI marks, including partial credit.”

1:45–2:30 — Show the two historical fraction mistakes, their questions and exact answers. Confirm the current gap and support flag. Edit feedback and practice if desired. Release results. “Only teacher-confirmed evidence contributes to the longitudinal record.”

2:30–3:00 — Switch to Student. Open Notifications, then Open my feedback. Show 11/15, question marks, explanations, feedback and progress.

3:00–3:45 — Switch to Teacher, open Support plans. Save the goal, measurable target, activity and date. Mark the activity completed and save. Review sample follow-up. Show 4/5 correct, the improving gap, and record Successful. “We track the effect of support, not only grades. All AI and assessment data in this demonstration are simulated.”

Record your screen using your preferred screen recorder. Export a 2–4 minute MP4; this source package does not include a recorded video.
