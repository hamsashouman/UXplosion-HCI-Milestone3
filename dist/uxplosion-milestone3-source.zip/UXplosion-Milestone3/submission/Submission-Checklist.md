# Milestone 3 submission checklist

Deadline: 14 November 2026.

- Interactive prototype, with access granted to the examiner and tested in a fresh browser.
- Public source repository link and README local/deployment instructions. The bundled source is ready to upload to your own repository; no public repository has been created in your GitHub account.
- Six HTD diagrams. Open the included draw.io file and export all six pages to PDF/PNG.
- Actual 2–4 minute recorded walkthrough. A timed script is included.
- Cover with UXplosion team names, IDs, tutorials and emails. Reuse and verify the details in Milestone 2.
- Full AI prompt and conversation history; export this conversation and any other AI conversations used for the project. A short summary is not a substitute for full history.

Scope: a browser-based frontend with simulated OCR, AI suggestions and sample historical assessments. Uploaded documents are previewed locally; their contents are not parsed. There is no real login, backend or student account separation. Use fictional assessment data for the demonstration.

- [ ] If replacing an existing hosted website, redeploy the revised `dist` directory and confirm the live page matches this ZIP.
- [ ] Test German sample, OCR correction, Q2 grading, evidence acknowledgement, support-plan target, and source download.


## Website revision validation

- [x] Two sequential submissions with prior teacher-released results retained in the demo.
- [x] German demo questions and model answers; simulated OCR clearly disclosed.
- [x] Teacher correction of OCR error changes suggested multiplication grade.
- [x] Teacher-confirmed learning gap, support flag, feedback, and student notification.
- [x] Measurable intervention target compared to teacher-confirmed fictional follow-up; contradictory Successful outcome blocked.
- [x] Mobile layout smoke test (390px width).
- [ ] Deploy the final `dist/` directory and verify the live link in a fresh browser.
- [ ] Provide repository URL and record the required walkthrough.
